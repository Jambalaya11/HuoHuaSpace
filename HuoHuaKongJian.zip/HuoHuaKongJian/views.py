from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
from Database.models import *

def home(request):
    context = {}
    return HttpResponse(json.dumps(context))

@csrf_exempt
def add_record(request):
    context = {"msg":"success", "code":0}
    userid = request.GET.get("userid")
    courseid = request.GET.get("courseid")
    case = Record(userid = userid, courseid = courseid)
    case.save()
    return HttpResponse(json.dumps(context))

@csrf_exempt
def record_return(request):
    context = {}
    for record in Record.objects.all():
        print record.id
    return HttpResponse(json.dumps(context))

